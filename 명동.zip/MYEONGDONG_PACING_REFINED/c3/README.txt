2030 MYEONGDONG — V7 BALANCED CINEMATIC

Open index.html in a recent desktop Chrome browser. No network required.
Scroll through the 10 scenes; choose a district at scene 06; switch experiences and set an external project link in scene 07. The project links are saved to this browser's localStorage.

The futuristic city images are user-provided visualizations. The graphics and crowd behaviors are illustrative animations, not physically accurate 3D or traffic simulations.

For best results: Chrome, desktop, 1440 x 900 or larger. Reduced-motion accessibility support is not fully implemented in this prototype.
