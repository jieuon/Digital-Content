2030 MYEONGDONG — PACING REFINED

Changes: unequal chapter scroll durations; longer MCU AI, city map and city simulation; shorter introductory and connective passages; source-to-source transitions briefly fade through black; scroll prompt only appears near the beginning.
Original selected candidate scenes and assets are retained.

QA: syntax and archive checks only unless a browser test is separately reported.
